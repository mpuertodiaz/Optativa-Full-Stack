var fs = require('fs')

console.log('A')
setTimeout(() => console.log('B'), 0)
fs.readFile(__filename, 'utf8', () => console.log('C'))
var texto = fs.readFileSync(__filename, 'utf8')
console.log('D', texto.length > 0)
